/**
 * Shared DOM helpers for Poshmark, Mercari, and Facebook Marketplace content scripts.
 */
(function attachRccHelpers() {
  if (window.__rccHelpers) return;

  function waitForSelector(selectors, timeoutMs = 10000) {
    const list = Array.isArray(selectors) ? selectors : [selectors];
    return new Promise((resolve) => {
      for (const sel of list) {
        const found = document.querySelector(sel);
        if (found) return resolve(found);
      }

      const observer = new MutationObserver(() => {
        for (const sel of list) {
          const found = document.querySelector(sel);
          if (found) {
            observer.disconnect();
            resolve(found);
            return;
          }
        }
      });

      observer.observe(document.documentElement, {
        childList: true,
        subtree: true,
      });

      setTimeout(() => {
        observer.disconnect();
        resolve(null);
      }, timeoutMs);
    });
  }

  /**
   * React/Vue controlled-input safe setter.
   * Uses the native prototype value setter so synthetic state updates fire cleanly.
   */
  function setNativeValue(el, value) {
    if (!el) return false;
    el.focus();
    const proto =
      el.tagName === "TEXTAREA"
        ? HTMLTextAreaElement.prototype
        : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;

    if (setter) {
      setter.call(el, String(value));
    } else {
      el.value = String(value);
    }

    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.dispatchEvent(new Event("blur", { bubbles: true }));
    return true;
  }

  /**
   * Pads non-square images onto a crisp 1:1 white square canvas (up to 1600x1600)
   * so Poshmark's mandatory 1:1 cropper never chops off the top/bottom or sides of an item.
   * Already-square images (within 1.5%) are returned untouched.
   */
  async function padBlobToSquare(blob, maxSize = 1600) {
    let bmp = null;
    let objectUrl = null;
    try {
      let source = null;
      let w = 0;
      let h = 0;

      if (typeof createImageBitmap === "function") {
        bmp = await createImageBitmap(blob);
        source = bmp;
        w = bmp.width;
        h = bmp.height;
      } else {
        objectUrl = URL.createObjectURL(blob);
        const img = await new Promise((resolve, reject) => {
          const el = new Image();
          el.onload = () => resolve(el);
          el.onerror = reject;
          el.src = objectUrl;
        });
        source = img;
        w = img.naturalWidth || img.width;
        h = img.naturalHeight || img.height;
      }

      if (!w || !h) return blob;
      const maxDim = Math.max(w, h);
      if (Math.abs(w - h) / maxDim <= 0.015) {
        return blob; // Already square — preserve original bytes untouched
      }

      const size = Math.min(maxSize, maxDim);
      const scale = size / maxDim;
      const drawW = Math.round(w * scale);
      const drawH = Math.round(h * scale);
      const offsetX = Math.round((size - drawW) / 2);
      const offsetY = Math.round((size - drawH) / 2);

      const canvas = document.createElement("canvas");
      canvas.width = size;
      canvas.height = size;
      const ctx = canvas.getContext("2d");
      if (!ctx) return blob;

      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, size, size);
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = "high";
      ctx.drawImage(source, offsetX, offsetY, drawW, drawH);

      const squared = await new Promise((resolve) =>
        canvas.toBlob((out) => resolve(out || blob), "image/jpeg", 0.92)
      );
      return squared;
    } catch {
      return blob;
    } finally {
      if (bmp && typeof bmp.close === "function") {
        try {
          bmp.close();
        } catch {
          // ignore
        }
      }
      if (objectUrl) {
        URL.revokeObjectURL(objectUrl);
      }
    }
  }

  /**
   * Downloads master CDN images through the MV3 background service worker
   * (bypassing page CORS) and injects them into a file input via DataTransfer.
   * Pass `{ squarePad: true }` for Poshmark so non-square photos are fitted into 1:1 squares without cropping.
   */
  async function injectImageBlobs(fileInput, imageUrls, maxPhotos = 16, options = {}) {
    if (!fileInput || !Array.isArray(imageUrls) || imageUrls.length === 0) {
      return 0;
    }

    const squarePad = Boolean(options && options.squarePad);
    const dt = new DataTransfer();
    let count = 0;

    for (let i = 0; i < Math.min(imageUrls.length, maxPhotos); i++) {
      const url = imageUrls[i];
      try {
        const res = await chrome.runtime.sendMessage({
          type: "RCC_FETCH_IMAGE_BLOB",
          url,
        });
        if (!res?.ok || !res.base64) continue;

        const binary = atob(res.base64);
        const bytes = new Uint8Array(binary.length);
        for (let b = 0; b < binary.length; b++) {
          bytes[b] = binary.charCodeAt(b);
        }
        const origMime = res.mimeType || "image/jpeg";
        let finalBlob = new Blob([bytes], { type: origMime });
        if (squarePad) {
          finalBlob = await padBlobToSquare(finalBlob, 1600);
        }
        const mime = finalBlob.type || origMime;
        const ext = mime.includes("png")
          ? "png"
          : mime.includes("webp")
            ? "webp"
            : "jpg";
        const file = new File([finalBlob], `rcc-photo-${i + 1}.${ext}`, {
          type: mime,
        });
        dt.items.add(file);
        count += 1;
      } catch {
        continue;
      }
    }

    if (count > 0) {
      fileInput.files = dt.files;
      fileInput.dispatchEvent(new Event("input", { bubbles: true }));
      fileInput.dispatchEvent(new Event("change", { bubbles: true }));
    }
    return count;
  }

  function sleep(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  /**
   * Waits for a visible button/link matching any regex or exact text pattern and clicks it.
   */
  async function clickButtonByText(patterns, timeoutMs = 4000) {
    const start = Date.now();
    const list = Array.isArray(patterns) ? patterns : [patterns];
    while (Date.now() - start < timeoutMs) {
      const candidates = Array.from(
        document.querySelectorAll('button, a, [role="button"]')
      );
      for (const el of candidates) {
        if (el.disabled) continue;
        const rect = el.getBoundingClientRect();
        if (rect.width === 0 || rect.height === 0) continue;
        const txt = (el.textContent || "").replace(/\s+/g, " ").trim();
        const matched = list.some((p) =>
          p instanceof RegExp ? p.test(txt) : txt.toLowerCase() === String(p).toLowerCase()
        );
        if (matched) {
          el.click();
          return true;
        }
      }
      await sleep(250);
    }
    return false;
  }

  function showRccHud({
    title,
    message,
    tone = "info",
    actionLabel,
    onAction,
    secondaryLabel,
    onSecondaryAction,
  }) {
    let hud = document.getElementById("rcc-companion-hud");
    if (!hud) {
      hud = document.createElement("div");
      hud.id = "rcc-companion-hud";
      Object.assign(hud.style, {
        position: "fixed",
        bottom: "20px",
        right: "20px",
        zIndex: "2147483647",
        maxWidth: "360px",
        background: "#14151a",
        color: "#ffffff",
        borderRadius: "12px",
        padding: "14px 16px",
        boxShadow: "0 12px 32px rgba(0,0,0,0.28)",
        fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
        fontSize: "12px",
        lineHeight: "1.45",
      });
      document.body.appendChild(hud);
    }

    const accent =
      tone === "confirm"
        ? "#f59e0b"
        : tone === "success"
          ? "#10b981"
          : tone === "error"
            ? "#ef4444"
            : "#3b82f6";

    hud.style.borderLeft = `4px solid ${accent}`;
    hud.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:4px;">
        <strong style="font-size:13px;">${title}</strong>
        <button id="rcc-hud-close" style="background:none;border:none;color:#9ca3af;cursor:pointer;font-size:14px;">✕</button>
      </div>
      <div style="color:#d1d5db;">${message}</div>
      ${actionLabel ? `<button id="rcc-hud-action" style="margin-top:10px;width:100%;padding:8px 12px;border:none;border-radius:8px;background:${accent};color:#14151a;font-weight:700;cursor:pointer;font-size:12px;">${actionLabel}</button>` : ""}
      ${secondaryLabel ? `<button id="rcc-hud-secondary" style="margin-top:6px;width:100%;padding:6px 10px;border:1px solid #374151;border-radius:8px;background:transparent;color:#d1d5db;font-weight:600;cursor:pointer;font-size:11px;">${secondaryLabel}</button>` : ""}
    `;

    hud.querySelector("#rcc-hud-close")?.addEventListener("click", () => {
      hud.remove();
    });

    if (actionLabel && typeof onAction === "function") {
      hud.querySelector("#rcc-hud-action")?.addEventListener("click", onAction);
    }
    if (secondaryLabel && typeof onSecondaryAction === "function") {
      hud.querySelector("#rcc-hud-secondary")?.addEventListener("click", onSecondaryAction);
    }
  }

  function normalizeLabel(s) {
    return String(s || "")
      .toLowerCase()
      .replace(/&/g, " and ")
      .replace(/[^a-z0-9]+/g, " ")
      .trim();
  }

  function scoreOptionText(optionText, targetText) {
    const a = normalizeLabel(optionText);
    const b = normalizeLabel(targetText);
    if (!a || !b) return 0;
    if (a === b) return 1.0;

    // Short labels (e.g., "OS", "S", "M", "L", "XL", "8") MUST NOT substring-match inside longer words like "Poshmark"!
    if (b.length <= 3) {
      const words = a.split(" ");
      if (words.includes(b)) return 0.92;
      return 0;
    }

    if (a.startsWith(b) || b.startsWith(a)) return 0.9;
    // Only allow includes if target appears as whole word(s), not inside unrelated words
    const wordRe = new RegExp(`\\b${b.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`);
    if (wordRe.test(a)) return 0.85;

    const tokA = new Set(a.split(" ").filter((t) => t.length >= 2));
    const tokB = new Set(b.split(" ").filter((t) => t.length >= 2));
    if (tokA.size === 0 || tokB.size === 0) return 0;
    let overlap = 0;
    for (const t of tokB) {
      if (tokA.has(t)) overlap += 1;
    }
    return overlap / Math.max(tokA.size, tokB.size);
  }

  function isVisibleElement(el) {
    if (!el || el.disabled) return false;
    if (el.closest("#rcc-companion-hud")) return false;
    if (typeof el.checkVisibility === "function") {
      try {
        if (!el.checkVisibility({ checkOpacity: true, checkVisibilityCSS: true })) {
          return false;
        }
      } catch {
        // fallback below
      }
    }
    const style = window.getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden" || style.opacity === "0") {
      return false;
    }
    const rect = el.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return false;

    // Ensure no ancestor clips this element to 0 height/width (e.g. max-height:0; overflow:hidden)
    let p = el.parentElement;
    for (let depth = 0; depth < 6 && p && p !== document.body; depth++) {
      const ps = window.getComputedStyle(p);
      if (ps.display === "none" || ps.visibility === "hidden" || ps.opacity === "0") {
        return false;
      }
      if (ps.overflow === "hidden" || ps.overflowY === "hidden" || ps.overflow === "clip") {
        const pr = p.getBoundingClientRect();
        if (pr.height <= 2 || pr.width <= 2) return false;
      }
      p = p.parentElement;
    }
    return true;
  }

  function simulateHoverAndClick(el) {
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const opts = { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy };
    try {
      el.dispatchEvent(new MouseEvent("mouseenter", { ...opts, bubbles: false }));
      el.dispatchEvent(new MouseEvent("mouseover", opts));
    } catch {
      // ignore
    }
    el.click();
  }

  function resolveClickableTrigger(el) {
    if (!el) return null;
    let cur = el;
    let best = el;
    for (let depth = 0; depth < 4 && cur && cur !== document.body; depth++) {
      const rect = cur.getBoundingClientRect();
      const cls = String(cur.className || "").toLowerCase();
      const cs = window.getComputedStyle(cur);
      const isControl =
        cur.tagName === "BUTTON" ||
        cur.tagName === "SELECT" ||
        cur.getAttribute("role") === "button" ||
        cur.getAttribute("role") === "combobox" ||
        cur.hasAttribute("tabindex") ||
        cls.includes("dropdown__selector") ||
        cls.includes("dropdown-toggle") ||
        cls.includes("select");
      if (rect.height >= 26 && rect.height <= 76 && rect.width >= 90 && rect.width <= 600) {
        if (isControl || cs.cursor === "pointer") {
          best = cur;
          if (isControl) break;
        }
      }
      cur = cur.parentElement;
    }
    return best;
  }

  /**
   * Class-agnostic visible trigger finder: locates ANY visible box whose text
   * or input placeholder matches `patterns` (e.g. "Select Category", "Select Size",
   * "Select Condition") and resolves its clickable parent trigger.
   */
  async function findDropdownTriggerByText(patterns, timeoutMs = 3000) {
    const list = Array.isArray(patterns) ? patterns : [patterns];
    const matchesPattern = (txt) =>
      list.some((p) =>
        p instanceof RegExp
          ? p.test(txt)
          : txt.toLowerCase().includes(String(p).toLowerCase())
      );

    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      let best = null;
      let bestArea = Infinity;

      const all = Array.from(
        document.querySelectorAll("div, button, span, p, label, input, select")
      );
      for (const el of all) {
        if (!isVisibleElement(el)) continue;
        const rect = el.getBoundingClientRect();
        if (rect.height > 80 || rect.height < 14 || rect.width < 40) continue;

        const txt =
          el.tagName === "INPUT"
            ? String(el.placeholder || el.value || "").trim()
            : (el.textContent || "").replace(/\s+/g, " ").trim();
        if (!txt || txt.length > 55) continue;

        if (matchesPattern(txt)) {
          const clickable = resolveClickableTrigger(el);
          const tr = clickable.getBoundingClientRect();
          const area = tr.width * tr.height;
          if (area < bestArea) {
            bestArea = area;
            best = clickable;
          }
        }
      }
      if (best) return best;
      await sleep(200);
    }
    return null;
  }

  function snapshotVisibleElements() {
    const set = new Set();
    const els = document.querySelectorAll("li, a, button, div, span, label, p");
    for (const el of els) {
      if (isVisibleElement(el)) set.add(el);
    }
    return set;
  }

  /**
   * Locates currently open dropdown menus (globally OR inside a trigger's parent wrapper).
   */
  function findOpenDropdownContainers(trigger = null) {
    const openMenus = [];
    const seen = new Set();
    const pushIfOpen = (el) => {
      if (!el || seen.has(el) || !isVisibleElement(el)) return;
      seen.add(el);
      openMenus.push(el);
    };

    // 1. Check sibling menus inside the trigger's closest dropdown wrapper first!
    if (trigger) {
      const wrapper =
        trigger.closest('[class*="dropdown"], [class*="select"], [data-test]') ||
        trigger.parentElement?.parentElement;
      if (wrapper) {
        for (const el of Array.from(
          wrapper.querySelectorAll('ul, [role="listbox"], [role="menu"], [class*="menu"], [class*="list"], [class*="options"]')
        )) {
          if (el !== trigger && !el.contains(trigger)) {
            pushIfOpen(el);
          }
        }
      }
    }

    // 2. Check global portals / modals / popovers
    const selectors = [
      '.dropdown__menu',
      '[class*="dropdown__menu"]',
      '[class*="dropdown-menu"]',
      '[role="listbox"]',
      '[role="menu"]',
      'ul[class*="menu"]',
      'div[class*="popover"]',
      '.modal__body',
    ];
    for (const sel of selectors) {
      for (const el of Array.from(document.querySelectorAll(sel))) {
        pushIfOpen(el);
      }
    }
    return openMenus;
  }

  function findBestMatchingElement(candidates, targetLabel) {
    const labels = Array.isArray(targetLabel) ? targetLabel : [targetLabel];
    let bestEl = null;
    let bestScore = 0;
    let bestArea = Infinity;

    for (const el of candidates) {
      if (!isVisibleElement(el)) continue;
      const rect = el.getBoundingClientRect();
      if (rect.height > 72 || rect.height < 16 || rect.width < 20) continue;

      const txt = (el.textContent || "").replace(/\s+/g, " ").trim();
      if (!txt || txt.length > 55) continue;
      if (/seller fee|learn about|learn more|help center|terms|privacy/i.test(txt)) {
        continue;
      }

      for (const lbl of labels) {
        const score = scoreOptionText(txt, lbl);
        const area = rect.width * rect.height;
        if (score > bestScore || (score === bestScore && score > 0 && area < bestArea)) {
          bestScore = score;
          bestEl = el;
          bestArea = area;
        }
      }
    }
    return { bestEl, bestScore };
  }

  /**
   * Finds and clicks the best visible option matching `targetLabel` inside
   * newly-opened DOM elements (DOM-diff) OR open dropdown menus next to `trigger`.
   */
  async function clickMatchingOption(targetLabel, timeoutMs = 2400, beforeSnapshot = null, trigger = null) {
    if (!targetLabel) return { ok: false, sampleOptions: [] };
    const start = Date.now();
    let lastSample = [];

    while (Date.now() - start < timeoutMs) {
      const candidateSet = new Set();

      if (beforeSnapshot) {
        const allNow = Array.from(
          document.querySelectorAll("li, a, button, div, span, label, p")
        );
        for (const el of allNow) {
          if (!beforeSnapshot.has(el) && isVisibleElement(el)) {
            candidateSet.add(el);
          }
        }
      }

      // Always also inspect open dropdown containers (handles pre-mounted sibling menus!)
      const containers = findOpenDropdownContainers(trigger);
      for (const c of containers) {
        for (const el of Array.from(
          c.querySelectorAll(
            '[role="option"], [role="menuitem"], [role="menuitemradio"], li, button, a, label, div, span'
          )
        )) {
          if (isVisibleElement(el)) candidateSet.add(el);
        }
      }

      const candidates = Array.from(candidateSet);
      if (candidates.length > 0) {
        const uniqTexts = [];
        for (const el of candidates) {
          const r = el.getBoundingClientRect();
          if (r.height > 72 || r.height < 16) continue;
          const t = (el.textContent || "").replace(/\s+/g, " ").trim();
          if (t && t.length <= 45 && !uniqTexts.includes(t)) {
            uniqTexts.push(t);
            if (uniqTexts.length >= 12) break;
          }
        }
        lastSample = uniqTexts;

        const { bestEl, bestScore } = findBestMatchingElement(candidates, targetLabel);
        if (bestEl && bestScore >= 0.78) {
          bestEl.scrollIntoView({ block: "nearest" });
          simulateHoverAndClick(bestEl);
          return { ok: true, matchedText: (bestEl.textContent || "").trim(), sampleOptions: lastSample };
        }
      }

      await sleep(220);
    }
    return { ok: false, sampleOptions: lastSample };
  }

  /**
   * Selects a value on a native <select> element by fuzzy label matching.
   */
  function selectNativeOption(selectEl, targetLabel) {
    if (!selectEl || selectEl.tagName !== "SELECT" || !targetLabel) return false;
    const labels = Array.isArray(targetLabel) ? targetLabel : [targetLabel];
    let bestOpt = null;
    let bestScore = 0;
    for (const opt of Array.from(selectEl.options)) {
      for (const lbl of labels) {
        const score = scoreOptionText(opt.textContent || opt.label || opt.value, lbl);
        if (score > bestScore) {
          bestScore = score;
          bestOpt = opt;
        }
      }
    }
    if (bestOpt && bestScore >= 0.72) {
      selectEl.value = bestOpt.value;
      selectEl.dispatchEvent(new Event("input", { bubbles: true }));
      selectEl.dispatchEvent(new Event("change", { bubbles: true }));
      return true;
    }
    return false;
  }

  function describeAncestors(el) {
    const chain = [];
    let cur = el;
    for (let i = 0; i < 4 && cur && cur !== document.body; i++) {
      const cls = String(cur.className || "").trim().split(/\s+/).slice(0, 3).join(".");
      const dt = cur.getAttribute("data-test") || cur.getAttribute("data-et-name") || "";
      chain.push(`${cur.tagName}${cls ? "." + cls : ""}${dt ? `[${dt}]` : ""}`);
      cur = cur.parentElement;
    }
    return chain.join(" < ");
  }

  /**
   * Opens a custom dropdown/combobox trigger using clean click + DOM-diff + sibling menu lookup.
   */
  async function selectDropdownSequence(triggerSelectors, labels, triggerTextPatterns = null, debugOut = null) {
    const cleanLabels = (labels || []).filter((l) =>
      Array.isArray(l) ? l.length > 0 : Boolean(l && String(l).trim())
    );
    if (cleanLabels.length === 0) return false;

    let trigger = null;
    if (triggerTextPatterns) {
      trigger = await findDropdownTriggerByText(triggerTextPatterns, 2200);
    }
    if (!trigger && triggerSelectors) {
      trigger = await waitForSelector(triggerSelectors, 1800);
    }
    if (!trigger || !isVisibleElement(trigger)) {
      if (debugOut) debugOut.push(`Trigger not found for ${JSON.stringify(cleanLabels)}`);
      return false;
    }

    const beforeText = (trigger.textContent || "").replace(/\s+/g, " ").trim();

    if (trigger.tagName === "SELECT") {
      const ok = selectNativeOption(trigger, cleanLabels[cleanLabels.length - 1]);
      if (debugOut) debugOut.push(`Native <select> "${beforeText}" -> ${ok}`);
      return ok;
    }

    const beforeSnapshot = snapshotVisibleElements();
    trigger.scrollIntoView({ block: "center" });
    await sleep(150);
    // Single clean click first (avoids mousedown+click double-toggle!)
    trigger.click();
    await sleep(550);

    // If nothing opened, also try clicking the first child or parent wrapper
    if (
      findOpenDropdownContainers(trigger).length === 0 &&
      Array.from(document.querySelectorAll("li, a, button, div")).filter(
        (el) => !beforeSnapshot.has(el) && isVisibleElement(el)
      ).length === 0
    ) {
      if (trigger.parentElement) {
        trigger.parentElement.click();
        await sleep(500);
      }
    }

    let clickedCount = 0;
    let lastSamples = [];
    for (const label of cleanLabels) {
      const stepRes = await clickMatchingOption(label, 2200, beforeSnapshot, trigger);
      lastSamples = stepRes.sampleOptions || [];
      if (stepRes.ok) {
        clickedCount += 1;
        await sleep(500);
      } else {
        if (debugOut) {
          debugOut.push(
            `Trigger (${describeAncestors(trigger)}) ("${beforeText}") missed ${JSON.stringify(label)}; saw: [${lastSamples.slice(0, 8).join(", ")}]`
          );
        }
        break;
      }
    }

    const afterText = (trigger.textContent || "").replace(/\s+/g, " ").trim();
    const changed = afterText !== beforeText;
    if (debugOut && clickedCount === cleanLabels.length) {
      debugOut.push(`OK "${beforeText}" -> "${afterText}"`);
    }
    return clickedCount > 0 && (changed || clickedCount === cleanLabels.length);
  }

  window.__rccHelpers = {
    waitForSelector,
    setNativeValue,
    injectImageBlobs,
    sleep,
    clickButtonByText,
    simulateHoverAndClick,
    findDropdownTriggerByText,
    clickMatchingOption,
    selectNativeOption,
    selectDropdownSequence,
    showRccHud,
  };
})();
